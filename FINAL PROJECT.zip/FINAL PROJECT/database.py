from pymongo import MongoClient
import os

MONGO_URL = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DATABASE_NAME", "hostel_db") # Simpler database name

client = None
db = None

def connect_db():
    global client, db
    client = MongoClient(MONGO_URL)
    db = client[DB_NAME]

def disconnect_db():
    global client
    if client:
        client.close()

def get_db():
    return db
