from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from database import get_db
from auth import hash_pw, verify_pw, create_jwt_token, get_current_user

router = APIRouter(prefix="/api/auth", tags=["Auth"])

class UserSchema(BaseModel):
    username: str
    password: str
    role: str = "user"

class LoginSchema(BaseModel):
    username: str
    password: str

@router.post("/register")
def register_user(user_data: UserSchema):
    db = get_db()
    if db.users.find_one({"username": user_data.username}):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username taken")
    
    hashed_password = hash_pw(user_data.password)
    user_dict = user_data.dict()
    user_dict["password"] = hashed_password
    db.users.insert_one(user_dict)
    return {"message": "User created"}

@router.post("/token")
def login_user(login_data: LoginSchema):
    db = get_db()
    user_in_db = db.users.find_one({"username": login_data.username})
    
    if not user_in_db or not verify_pw(login_data.password, user_in_db["password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Wrong username or password",
        )
    
    token = create_jwt_token(
        data={"user_id": str(user_in_db["_id"]), "role": user_in_db["role"]}
    )
    return {"access_token": token, "token_type": "bearer"}

@router.get("/me")
def get_my_info(current_user: dict = Depends(get_current_user)):
    return current_user
