from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from bson.objectid import ObjectId
from database import get_db
from auth import get_current_user, get_admin_user

router = APIRouter(prefix="/api/wardens", tags=["Wardens"])

class Warden(BaseModel):
    name: str
    email: str
    phone: str | None = None
    block: str | None = None

# Helper to convert ObjectId to string for responses
def warden_to_dict(warden) -> dict:
    warden["id"] = str(warden["_id"])
    del warden["_id"]
    return warden

@router.post("/")
def create_warden(warden_data: Warden, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    if db.wardens.find_one({"email": warden_data.email}):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Warden email exists")
    
    new_warden = warden_data.dict()
    result = db.wardens.insert_one(new_warden)
    created_warden = db.wardens.find_one({"_id": result.inserted_id})
    return warden_to_dict(created_warden)

@router.get("/")
def get_all_wardens(user: dict = Depends(get_current_user)):
    db = get_db()
    wardens_list = []
    for w in db.wardens.find():
        wardens_list.append(warden_to_dict(w))
    return wardens_list

@router.get("/{warden_id}")
def get_warden(warden_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    try:
        warden = db.wardens.find_one({"_id": ObjectId(warden_id)})
        if not warden:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Warden not found")
        return warden_to_dict(warden)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")

@router.put("/{warden_id}")
def update_warden(warden_id: str, warden_update: Warden, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        updated_warden = db.wardens.find_one_and_update(
            {"_id": ObjectId(warden_id)},
            {"$set": warden_update.dict(exclude_unset=True)},
            return_document=True
        )
        if not updated_warden:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Warden not found")
        return warden_to_dict(updated_warden)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID or data")

@router.delete("/{warden_id}")
def delete_warden(warden_id: str, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        result = db.wardens.delete_one({"_id": ObjectId(warden_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Warden not found")
        return {"message": "Warden deleted"}
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")
