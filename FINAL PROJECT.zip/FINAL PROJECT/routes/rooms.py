from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from bson.objectid import ObjectId
from database import get_db
from auth import get_current_user, get_admin_user

router = APIRouter(prefix="/api/rooms", tags=["Rooms"])

class Room(BaseModel):
    room_num: str
    block: str
    capacity: int
    occupancy: int = 0
    warden_id: str | None = None

# Helper to convert ObjectId to string for responses
def room_to_dict(room) -> dict:
    room["id"] = str(room["_id"])
    del room["_id"]
    if room.get("warden_id"): room["warden_id"] = str(room["warden_id"])
    return room

@router.post("/")
def create_room(room_data: Room, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    if db.rooms.find_one({"room_num": room_data.room_num}):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Room number exists")
    
    new_room = room_data.dict()
    if new_room.get("warden_id"): new_room["warden_id"] = ObjectId(new_room["warden_id"])
    
    result = db.rooms.insert_one(new_room)
    created_room = db.rooms.find_one({"_id": result.inserted_id})
    return room_to_dict(created_room)

@router.get("/")
def get_all_rooms(user: dict = Depends(get_current_user)):
    db = get_db()
    rooms_list = []
    for r in db.rooms.find():
        rooms_list.append(room_to_dict(r))
    return rooms_list

@router.get("/{room_id}")
def get_room(room_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    try:
        room = db.rooms.find_one({"_id": ObjectId(room_id)})
        if not room:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Room not found")
        return room_to_dict(room)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")

@router.put("/{room_id}")
def update_room(room_id: str, room_update: Room, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        update_data = room_update.dict(exclude_unset=True)
        if update_data.get("warden_id"): update_data["warden_id"] = ObjectId(update_data["warden_id"])
        
        updated_room = db.rooms.find_one_and_update(
            {"_id": ObjectId(room_id)},
            {"$set": update_data},
            return_document=True
        )
        if not updated_room:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Room not found")
        return room_to_dict(updated_room)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID or data")

@router.delete("/{room_id}")
def delete_room(room_id: str, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        result = db.rooms.delete_one({"_id": ObjectId(room_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Room not found")
        return {"message": "Room deleted"}
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")
