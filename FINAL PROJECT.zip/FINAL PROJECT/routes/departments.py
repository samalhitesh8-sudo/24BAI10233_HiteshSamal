from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from bson.objectid import ObjectId
from database import get_db
from auth import get_current_user, get_admin_user

router = APIRouter(prefix="/api/departments", tags=["Departments"])

class Department(BaseModel):
    name: str
    code: str
    head: str | None = None
    contact: str | None = None

# Helper to convert ObjectId to string for responses
def dept_serializer(dept) -> dict:
    dept["id"] = str(dept["_id"])
    del dept["_id"]
    return dept

@router.post("/")
def create_dept(dept: Department, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    if db.departments.find_one({"code": dept.code}):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Department code exists")
    
    new_dept = dept.dict()
    result = db.departments.insert_one(new_dept)
    created_dept = db.departments.find_one({"_id": result.inserted_id})
    return dept_serializer(created_dept)

@router.get("/")
def get_all_depts(user: dict = Depends(get_current_user)):
    db = get_db()
    depts = []
    for d in db.departments.find():
        depts.append(dept_serializer(d))
    return depts

@router.get("/{dept_id}")
def get_dept(dept_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    try:
        dept = db.departments.find_one({"_id": ObjectId(dept_id)})
        if not dept:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Department not found")
        return dept_serializer(dept)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")

@router.put("/{dept_id}")
def update_dept(dept_id: str, dept_update: Department, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        updated_dept = db.departments.find_one_and_update(
            {"_id": ObjectId(dept_id)},
            {"$set": dept_update.dict(exclude_unset=True)},
            return_document=True
        )
        if not updated_dept:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Department not found")
        return dept_serializer(updated_dept)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID or data")

@router.delete("/{dept_id}")
def delete_dept(dept_id: str, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        result = db.departments.delete_one({"_id": ObjectId(dept_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Department not found")
        return {"message": "Department deleted"}
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")
