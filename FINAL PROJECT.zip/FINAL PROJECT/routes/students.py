from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from bson.objectid import ObjectId
from database import get_db
from auth import get_current_user, get_admin_user

router = APIRouter(prefix="/api/students", tags=["Students"])

class Student(BaseModel):
    enrollment_num: str
    first_name: str
    last_name: str
    email: str
    phone: str | None = None
    dept_id: str | None = None
    room_id: str | None = None

# Helper to convert ObjectId to string for responses
def student_to_dict(student) -> dict:
    student["id"] = str(student["_id"])
    del student["_id"]
    if student.get("dept_id"): student["dept_id"] = str(student["dept_id"])
    if student.get("room_id"): student["room_id"] = str(student["room_id"])
    return student

@router.post("/")
def create_student(student_data: Student, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    if db.students.find_one({"enrollment_num": student_data.enrollment_num}):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Enrollment number exists")
    
    new_student = student_data.dict()
    if new_student.get("dept_id"): new_student["dept_id"] = ObjectId(new_student["dept_id"])
    if new_student.get("room_id"): new_student["room_id"] = ObjectId(new_student["room_id"])
    
    result = db.students.insert_one(new_student)
    created_student = db.students.find_one({"_id": result.inserted_id})
    return student_to_dict(created_student)

@router.get("/")
def get_all_students(user: dict = Depends(get_current_user)):
    db = get_db()
    students_list = []
    for s in db.students.find():
        students_list.append(student_to_dict(s))
    return students_list

@router.get("/{student_id}")
def get_student(student_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    try:
        student = db.students.find_one({"_id": ObjectId(student_id)})
        if not student:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
        return student_to_dict(student)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")

@router.put("/{student_id}")
def update_student(student_id: str, student_update: Student, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        update_data = student_update.dict(exclude_unset=True)
        if update_data.get("dept_id"): update_data["dept_id"] = ObjectId(update_data["dept_id"])
        if update_data.get("room_id"): update_data["room_id"] = ObjectId(update_data["room_id"])
        
        updated_student = db.students.find_one_and_update(
            {"_id": ObjectId(student_id)},
            {"$set": update_data},
            return_document=True
        )
        if not updated_student:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
        return student_to_dict(updated_student)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID or data")

@router.delete("/{student_id}")
def delete_student(student_id: str, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        result = db.students.delete_one({"_id": ObjectId(student_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
        return {"message": "Student deleted"}
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")
