from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel
from bson.objectid import ObjectId
from database import get_db
from auth import get_current_user, get_admin_user
from datetime import datetime

router = APIRouter(prefix="/api/payments", tags=["Payments"])

class Payment(BaseModel):
    student_id: str
    amount: float
    due_date: datetime
    status: str = "pending"
    paid_date: datetime | None = None

# Helper to convert ObjectId to string for responses
def payment_to_dict(payment) -> dict:
    payment["id"] = str(payment["_id"])
    del payment["_id"]
    if payment.get("student_id"): payment["student_id"] = str(payment["student_id"])
    return payment

@router.post("/")
def create_payment(payment_data: Payment, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    new_payment = payment_data.dict()
    new_payment["student_id"] = ObjectId(new_payment["student_id"])
    
    result = db.payments.insert_one(new_payment)
    created_payment = db.payments.find_one({"_id": result.inserted_id})
    return payment_to_dict(created_payment)

@router.get("/")
def get_all_payments(user: dict = Depends(get_current_user)):
    db = get_db()
    payments_list = []
    for p in db.payments.find():
        payments_list.append(payment_to_dict(p))
    return payments_list

@router.get("/{payment_id}")
def get_payment(payment_id: str, user: dict = Depends(get_current_user)):
    db = get_db()
    try:
        payment = db.payments.find_one({"_id": ObjectId(payment_id)})
        if not payment:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Payment not found")
        return payment_to_dict(payment)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")

@router.put("/{payment_id}")
def update_payment(payment_id: str, payment_update: Payment, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        update_data = payment_update.dict(exclude_unset=True)
        if update_data.get("student_id"): update_data["student_id"] = ObjectId(update_data["student_id"])
        
        updated_payment = db.payments.find_one_and_update(
            {"_id": ObjectId(payment_id)},
            {"$set": update_data},
            return_document=True
        )
        if not updated_payment:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Payment not found")
        return payment_to_dict(updated_payment)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID or data")

@router.delete("/{payment_id}")
def delete_payment(payment_id: str, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        result = db.payments.delete_one({"_id": ObjectId(payment_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Payment not found")
        return {"message": "Payment deleted"}
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")

@router.post("/{payment_id}/mark-paid")
def mark_payment_paid(payment_id: str, admin_user: dict = Depends(get_admin_user)):
    db = get_db()
    try:
        updated_payment = db.payments.find_one_and_update(
            {"_id": ObjectId(payment_id)},
            {"$set": {"status": "paid", "paid_date": datetime.utcnow()}},
            return_document=True
        )
        if not updated_payment:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Payment not found")
        return payment_to_dict(updated_payment)
    except:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid ID")
