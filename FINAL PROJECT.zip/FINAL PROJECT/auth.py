from jose import JWTError, jwt
from bcrypt import hashpw, checkpw, gensalt
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from datetime import datetime, timedelta
import os

SECRET_KEY = os.getenv("JWT_SECRET", "my-secret-key") # Simple secret key
ALGORITHM = "HS256"

security = HTTPBearer()

def hash_pw(password: str) -> str:
    return hashpw(password.encode(), gensalt()).decode()

def verify_pw(password: str, hashed_password: str) -> bool:
    return checkpw(password.encode(), hashed_password.encode())

def create_jwt_token(data: dict) -> str:
    expire = datetime.utcnow() + timedelta(minutes=30)
    data.update({"exp": expire})
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("user_id")
        user_role: str = payload.get("role")
        if user_id is None or user_role is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
        return {"user_id": user_id, "role": user_role}
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

def get_admin_user(current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required")
    return current_user
