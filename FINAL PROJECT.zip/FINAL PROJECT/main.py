from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

from database import connect_db, disconnect_db
from routes import auth, departments, students, rooms, wardens, payments

load_dotenv()

app = FastAPI(title="Hostel Management App") # Simpler title

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup_event():
    connect_db()

@app.on_event("shutdown")
def shutdown_event():
    disconnect_db()

app.include_router(auth.router)
app.include_router(departments.router)
app.include_router(students.router)
app.include_router(rooms.router)
app.include_router(wardens.router)
app.include_router(payments.router)

@app.get("/health")
def health_check():
    return {"status": "ok"}

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
